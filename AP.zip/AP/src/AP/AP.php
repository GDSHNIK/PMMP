<?php

namespace AP;
use pocketmine\scheduler\TaskScheduler;
use pocketmine\entity\Effect;
use pocketmine\level\sound\
{
    AnvilBreakSound,
    AnvilFallSound,
    AnvilUseSound,
    BlazeShootSound,
    ClickSOund,
    DoorBumpSound,
    DoorCrashSound,
    DoorSound,
    EndermanTeleportSound,
    FizSound,
    GenericSound,
    GhastShootSound,
    GhastSound,
    LaunchSound,
    PopSound
};
use pocketmine\utils\Config;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use _64FF00\PurePerms;
use pocketmine\Player;
use pocketmine\network\protocol\LevelPacketEvent;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use pocketmine\math\Vector3;
use onebone\economyapi\EconomyAPI;
class AP extends PluginBase implements Listener
{
	public $config,$fractionnicks,$serialnum,$moneybal,$message,$name,$ac,$ai;
	public function checkTP()
	{
	foreach($this->getServer()->getOnlinePlayers() as $p)
	{
	if ($p->getX() >= 41 && $p->getX() <= 42 && $p->getY() == 66 && $p->getZ() >= 37.4 && $p->getZ() <= 38)
	{
	$p->sendMessage("§l§bВы на 2 этаже.");
	$p->teleport(new Vector3(41.5,72,41.4));
	return true;
	}
	else if ($p->getX() >= 41 && $p->getX() <= 42 && $p->getY() == 72 && $p->getZ() >= 37.4 && $p->getZ() <= 38)
	{
	$p->sendMessage("§l§eВы на 1 этаже.");
	$p->teleport(new Vector3(41.5,66,41.4));
	return true;
	}
	
	}
	return true;
	}
	public function checkheal($n,$p)
	{
	$c = $this->config->get("healing$n");
	if ($c == true)
	{
	$x=$p->getX();
	$y=$p->getY();
	$z=$p->getZ();
	if ($x <=44 && $x>=40 && $y == 66 && $z>= 55 && $z <= 56)
	{
	$p->sendMessage("§c§oВы лечитесь,и не можете уйти!");
	$p->teleport(new Vector3(42,66,55));
	return true;
	}
	return true;
	}
	else
	{
	$this->getServer()->getScheduler()->cancelAllTasks();
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new TP($this),1);
		return true;
	}
	}
	public function heal()
	{
	$pn= $this->config->get("n");
		$p = $this->getServer()->getPlayer($pn);
		$sn= $this->config->get("sn");
		$sp = $this->getServer()->getPlayer($sn);
		$he = $sp->getHealth();
	if ($he<20)
	{
	$hp = $sp->getHealth();
	$sp->setHealth($hp + 1);
	$p->sendMessage("§l§fУ пациента §c$hp ♥");
	return true;
	}
	else
	{
	$this->getServer()->getScheduler()->cancelAllTasks();
	$this->getServer()->getScheduler()->scheduleRepeatingTask(new TP($this),1);

	$p->sendMessage("§e§lПациент выздоровел");
	$sp->addTitle("§a§lВы вылечились!","§l§eВы можете уходить.",10,20*5,20);
	}
	}
	public function endTP()
	{
	$this->config->set("minigametp",false);
	$this->config->save();
	foreach($this->getServer()->getOnlinePlayers() as $p)
	{
	$p->addTitle("§l§cТелепорт закрыт.","§l§aУдачи в след.раз!",20,20*4,20);
	}
	return true;
	}
	public function bonus($p)
	{
	$ppapi=$this->getServer()->getPluginManager()->getPlugin("PurePerms");
	$pg = $ppapi->getUserDataMgr()->getGroup($p)->getName();
	$gs="SMI";
	$awarded = $this->config->get("smiawarded$p");
	if ($pg === "SMI" && $awarded == "false")
	{
	EconomyAPI::getInstance()->addMoney($p,600);
	$p->sendMessage("§l§aВы получили награду!");
	$awarded=$this->config->set("smiawarded$p","true");
	$this->config->save();
	return $this->config->get("smiawarded$p");
	}
	else if ($awarded == "true")
	{
	$p->sendMessage("§l§cВы уже получили награду!");
	return true;
	}
	else
	{
	$p->sendMessage("§l§cОшибка!");
	}
	}

	public function onJoin(PlayerJoinEvent $event){
	    $event->setJoinMessage(null);
	$p = $event->getPlayer(); //Player
	$n = $p->getName(); //PlayerName
	$p->addTitle("§l§aДень добрый!","§l§eПриятной игры!",20,20*5,20*2);
							$this->getServer()->getScheduler()->scheduleRepeatingTask(new TP($this),1);
	if (!$this->config->exists("carbuyed$n"))
	{
	$this->config->set("carbuyed$n",false);
	$this->config->save();
	return true;
	}
	if ($this->config->exists("sernum$n"))
	{
	$this->config->set("sernum$n",41);
	$this->config->save();
	return $this->config->get("sernum$n");
	}
	else
	{
		$this->config->set("sernum$n",41);
		$this->config->save();
		return $this->config->get("sernum$n");
		}

    //§
    return true;
	}

    public function onCommand(CommandSender $comsend,Command $ap,$label,array $args)
    {
    $ecapi=EconomyAPI::getInstance();
    $mym=$ecapi->myMoney($comsend->getPlayer());
	if ($ap == "gps" && isset($args[0]) && $mym >= 10)
	{
		$arg = $args[0];
		if ($arg == "1")
		{
			$player=$comsend->getPlayer();
	     	$comsend->sendMessage("§l§eТелепортация на вокзал...");
			$comsend->teleport(new Vector3(123,65,131));
			EconomyAPI::getInstance()->reduceMoney($player, 10);
			return true;
		}
		else if ($arg == "2")
		{
			$player=$comsend->getPlayer();
			$comsend->sendMessage("§l§eТелепортация в мэрию...");
		EconomyAPI::getInstance()->reduceMoney($player, 10);
		$comsend->teleport(new Vector3(105,66,115));
			return true;
		}
		else if ($arg == "3")
		{
			$player=$comsend->getPlayer();
			$comsend->sendMessage("§e§lТелепортация на базар...");
			EconomyAPI::getInstance()->reduceMoney($player, 10);
			return true;
		}
		else if ($arg == "4")
		{
		$player=$comsend->getPlayer();
		$comsend->sendMessage("§l§eТелепортация в СМИ...");
		EconomyAPI::getInstance()->reduceMoney($player, 10);
		$comsend->teleport(new Vector3(81,67,101));
		return true;
		} 
		else
		{
			$comsend->sendMessage("§a§lИспользуйте §c/gps|/gps 1/2/3/4");
			return true;
		}
		return true;
	}
	else if ($mym<10)
	{
	$comsend->sendMessage("§l§c          Где наши деньги? =).         ");
	}
	if ($ap == "do" && !empty($args))
	{
		if (isset($args[30]))
			{
		$comsend->sendMessage("Не много ли слов?");
		return false;
			}
			else
			{
		$name = $comsend->getName();
	$this->getServer()->broadcastMessage("§l§a$args[0] $args[1] $args[2] $args[3] $args[4] $args[5] $args[6] $args[7] $args[8] $args[9] $args[10] $args[11] $args[12] $args[13] $args[14] $args[15] $args[16] $args[17] $args[18] $args[19] $args[20] $args[21] $args[22] $args[23] $args[24] $args[25] $args[26] $args[27] $args[28] $args[29]| -§l§c$name.");
	return true;
	}
	return true;
	}
	if ($ap == "minigame")
	{
	if (isset($args[0]))
	{
	$type= $args[0];
	if ($type == "QnA")
	{
	$pp = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
	$g = $pp->getUserDataMgr()->getGroup($comsend->getPlayer())->getName();
	if ($g != "Guest")
	{
	foreach($this->getServer()->getOnlinePlayers() as $p)
	{
	$this->config->set("minigametp",true);
	$this->config->save();
	$p->addTitle("§l§eОткрыт телепорт в","§l§eМини-игру §c'Викторина'.§eПриз:§a20.000$",20,20*58,20);
	return true;
	}
	return true;
	}
	return true;
	}
	else if ($type == "close")
	{
	$this->endTP();
	return true;
	}
	else if ($type == "tp")
	{
	$yon= $this->config->get("minigametp");
	if ($yon == true)
	{
	$comsend->teleport(new Vector3(105,66,115));
	$comsend->sendMessage("§l§eИгра проведется в мэрии.");
	return true;
	}
	else
	{
	$comsend->sendMessage("§l§cТелепорт закрыт.");
	return true;
	}
	return true;
	}
	return true;
	}
	else
	{
	$comsend->sendMessage("§lИспользуйте:§c/minigame tp|QnA|Close");
	}
	return true;
	}
	if ($ap == "startjob")
	{
	$pp = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
	$g = $pp->getUserDataMgr()->getGroup($comsend->getPlayer())->getName();
	if ($g == "Deputat")
	{
	$p= $comsend->getPlayer();
	$p->teleport(new Vector3(113,65,95));
	$level = $this->getServer()->getLevelByName("world");
	$level->addSound(new EndermanTeleportSound($p));
	$p->addTitle("§l§eВы в мэрии!","§l§aНачинайте работу.",20*2,20,4,20*2);
	return true;
	}
	else if ($g == "SMI")
	{
	$p= $comsend->getPlayer();
		$p->teleport(new Vector3(81,67,101));
		$level = $this->getServer()->getLevelByName("world");
		$level->addSound(new EndermanTeleportSound($p));
	$p->addTitle("§l§bВы в СМИ!","§l§aНачинайте работу.",20*2,20,4,20*2);
	return true;
	}
	else
	{
	$comsend->addTitle("§l§4Вы не работаете!","§l§5Устройтесь на работу.",20,20*3,20);
	return false;
	}
	return true;
	}
	//NEWS NEWS NEWS NEWS NEWS NEWS NEWS NEWS NEWS NEWS NEWS NEWS NEWS NEWS NEWS
	if ($ap == "news" && !empty($args))
	{
		$arg=$args[0];
		if ($arg == "start")
		{
			$this->getServer()->broadcastMessage("§l§e[ArizonaNews]§a°·°·°·Музыкальная заставка новостей·°·°·°§r");
			return true;
		}
		else if ($arg == "stop")
		{
			$this->getServer()->broadcastMessage("§l§e[ArizonaNews]§a°·°·°·Музыкальная заставка новостей·°·°·°§r");
			return true;
		}
		else
		{
			if (isset($args[50]))
			{
				$comsend->sendMessage("§l§cМного.Слов.");
				return true;
			}
			else
			{
				$nick = $comsend->getName();
			$this->getServer()->broadcastMessage("§l§e[$nick][ArizonaNews]§a$args[0] $args[1] $args[2] $args[3] $args[4] $args[5] $args[6] $args[7] $args[8] $args[9] $args[10] $args[11] $args[12] $args[13] $args[14] $args[15] $args[16] $args[17] $args[18] $args[19] $args[20] $args[21] $args[22] $args[23] $args[24] $args[25] $args[26] $args[27] $args[28] $args[29] $args[30] $args[31] $args[32] $args[33] $args[34] $args[35] $args[36] $args[37] $args[38] $args[39] $args[40] $args[41] $args[42] $args[43] $args[44] $args[45] $args[46] $args[47] $args[48] $args[49]");
		return true;
			}
			return true;
		
		}
		return true;
	}
	if ($ap == "adsend")
	{
	if (isset($args[20]))
	{
	$comsend->sendMessage("§l§o20 слов.");
	return true;
	}
	else
	{
	if (isset($args[0]))
	{
			$name = $comsend->getName();
			$this->config->set("sendername",$name);
			$this->config->save();
			$p = $comsend->getPlayer();
			$name = $comsend->getName();
			$message = "$args[0] $args[1] $args[2] $args[3] $args[4] $args[5] $args[6] $args[7] $args[8] $args[9] $args[10] $args[11] $args[12] $args[13] $args[14] $args[15] $args[16] $args[17] $args[18] $args[19]";
			$this->config->set("message",$message);
			$this->config->save();
			EconomyAPI::getInstance()->reduceMoney($p,500);
			
			foreach($this->getServer()->getOnlinePlayers() as $pl)
			{
			$neededgroup="SMI";
			$cfgn=$this->config->get("sendername");
			$ppapi=$this->getServer()->getPluginManager()->getPlugin("PurePerms");
			$pg = $ppapi->getUserDataMgr()->getGroup($pl)->getName();
			if ($pg == "SMI")
			{
			$pl->sendMessage("§l§c$cfgn §aприслал новое объявление!");
			return true;
			}
			}
			$comsend->sendMessage("§l§eОтправлено.Если обьявление не соответствует ПРО,оно будет отозвано.");		
			return $this->config->get(strtolower($name));		
			}
			else
			{
			$comsend->sendMessage("§l§cСлова где?");
			return true;
			}
			}
	return true;
	}
	if ($ap == "adpost" && isset($args[0]))
	{
	$name=$args[0];
	$msg= $this->config->get("message");
	$nick = $this->config->get("sendername");
	$sname=$comsend->getName();
	if ($name == "messages")
	{
	if ($msg == " " || $msg == null)
	{
	$comsend->sendMessage("§l§eНичего нету.§oПока-что закончили.");
	return true;
	}
	else{
	$comsend->sendMessage("§l§e$msg.§aВ студию отправил §c$nick");
	return true;
	}
	}
	else if ($nick == $name && $args[1] == "Y")
	{
	if ($msg == " " || $msg == null)
	{
	$comsend->sendMessage("§l§e[ArizonaNews]§aПользователь не отсылал объявление.");
	return true;
	}
	else{
	$pl=$comsend->getPlayer();
	$this->getServer()->getPlayer($name)->addTitle("§l§aВаше обьявление принято!","§l§eПоздравляем!",20,20*4,20);
	$ac = $this->config->get("adchecked$pl");
	$this->getServer()->broadcastMessage("§l§c[$sname]§e[ArizonaNews]§a$msg.§eОтправил:§c$nick");
	$this->config->set("message"," ");	
	$ac++;
	$this->config->set("adchecked$pl",$ac);
	$this->config->set("sendername"," ");
	$this->config->save();
	$comsend->sendMessage("§l§e[Бухгалтерия ArizonaNews]§aВам выдали 400$ за объявление!");	
	EconomyAPI::getInstance()->addMoney($pl,400);
	return true;
	}
	}
	else if ($nick == $name && $args[1] == "N")
	{
		$pln = $args[0];
		$pl = $this->getServer()->getPlayer($pln);
		$ai = $this->config->get("adignored$pl");
	$ai++;
	$comsend->sendMessage("§l§eВы отказали $name в объявлении.");
	$adc = $this->config->set("adignored$pl",$ai);
	$playertosendmsg = $this->getServer()->getPlayer($name)->sendMessage("§l§c$sname §eотказал вам в обьявлении.Причина:§cОбьявление нарушает ПРО!");
	$this->config->set("message"," ");
	$this->config->set("name"," ");
	$this->config->save();
	return true;
	}
	else
	{
	$comsend->sendMessage("§l§cНичем не ошиблись???");
	return true;
	}
	return true;
	}
	if ($ap == "shop")
	{
	$name=$comsend->getName();
	if (isset($args[0]))
	{
	$id=$args[0];
	$p=$comsend->getPlayer();
	$pm=EconomyAPI::getInstance()->myMoney($p);
	if ($pm>=100)
	{
	if (isset($args[1]))
	{
	$count=$args[1];
	if ($count>16 && $args[1] != null)
	{
	$comsend->sendMessage("§l§e[ArizonaShop]§cМаксимум 16 штук!");
	return true;
	}
	else
	{
	$comsend->sendMessage("§l§e[ArizonaShop]§aКурьер привез вам заказ!");
	$p->getInventory()->addItem(Item::get($id,0,$count));
	EconomyAPI::getInstance()->reduceMoney($p,100);
	return true;
	}
	}
	else
	{
		$comsend->sendMessage("§l§e[ArizonaShop]§cУкажите кол-во!");
	}
	return true;
	}
	else
	{
	$comsend->sendMessage("§l§e[ArizonaShop]§cУ вас недостаточно денег!");
	return true;
	}
	return true;
	}
	else
	{
	$comsend->sendMessage("§l§e[ArizonaShop]§aУкажите номер предмета для заказа!");
	return true;
	}
	return true;
	}
	if ($ap == "award")
	{
	$p =$comsend->getPlayer();
	if (isset($args[0]) && $args[0] == "list")
	{
	$comsend->sendMessage("§l§aСписок наград:\nЗа вступление в СМИ:600$ - /award SMI\nПравительство еще работает над наградами!");
	return true;
	}
	else if (isset($args[0]) && $args[0] == "SMI")
	{
	$this->bonus($p);
	return true;
	}
	else
	{
	$comsend->sendMessage("§l§cВведите /award list!");
	return true;
	}
	}
	if ($ap == "do")
	{
		return true;
	}
    if ($ap == "gps")
	{
		$comsend->sendMessage("§c§lКуда можно отправиться:\n §a1.Вокзал.\n §b2.Мэрия.\n §d3.Базар.\n §e4.СМИ.\n§c§l§o( За все у вас возьмут §a10$ §c)");
	return true;
	}
    if ($ap == "phone")
    {
    $sendername=$comsend->getName();
    $arg=$args[0];
    if ($arg == "message")
    {
    if (isset($args[1]))
    {
    $eapi=EconomyAPI::getInstance();
    $money=$eapi->myMoney($comsend->getPlayer());
    $moneybal=$this->config->get("money$sendername");
    if (!$this->config->exists("money$sendername"))
    {
    $moneybal = 200;
    $this->config->set("money$sendername",$moneybal);
    $eapi->reduceMoney($comsend->getPlayer(),100);
    $this->config->save();
    $comsend->sendMessage("§l§aПоздравляем!Вы - новый пользователь сети ArizonaCommunication!");
    return $this->config->get("money$sendername");
    }
    if ($moneybal>=50)
    {
    $name=$args[1];
    $comsend->sendMessage("§l§aОтправлено!");
    $this->getServer()->getPlayer($name)->sendMessage("§l§c$sendername §aприслал вам сообщение:§e$args[2] $args[3] $args[4] $args[5] $args[6] $args[7] $args[8] $args[9] $args[10] $args[11] $args[12] $args[13] $args[14] $args[15] $args[16] $args[17]");
    $moneybal-=50;
    $this->config->set("money$sendername",$moneybal);
    $this->config->save();
    return true;
    }
    else
    {
    $comsend->sendMessage("§l§cНедостаточно денег на счёту!");
    return true;
    }
    return true;
    }
    else
    {
    return false;
    }
    return true;
    }
    else if($arg == "deposit" && isset($args[1]))
    {
    $name=$args[1];
    $sum=$args[2];
    $eapi=EconomyAPI::getInstance();
    $moneyplayer=$eapi->myMoney($comsend->getPlayer());
    if ($moneyplayer >= $sum && $sum <=50000)
    {
    $moneybal+=$sum;
    $sname=$comsend->getName();
    $eapi->reduceMoney($this->getServer()->getPlayer($name),$sum);
    $this->getServer()->getPlayer($name)->sendMessage("§l§e$sname §aпополнил ваш счёт мобильного на $sum.!");
    $this->config->set("money$name",$moneybal);
    $this->config->save();
    return true;
    }
    else
    {
    $comsend->sendMessage("§l§cНедостаточно денег или сумма больше 50000!");
    return true;
    }
    }
    else if ($arg == "balance")
    {
    $player=$comsend->getName();
    $bal = $this->config->get("money$player");
    $comsend->sendMessage("§l§eВаш баланс:§a$bal $");
    }
    else
    {
    $comsend->sendMessage("§l§cВведите /phone (message Игрок Сообщение(15 слов макс))|deposit name count|balance");
    return true;
    }
    return true;
    }
    if ($ap == "heal")
    {
    if (isset($args[0]))
    {
    $pp = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
    $g = $pp->getUserDataMgr()->getGroup($comsend->getPlayer())->getName();
    
    if ($g == "Medic")
    {
    $pl = $this->getServer()->getPlayer($args[0]);
    	$this->getServer()->getScheduler()->scheduleRepeatingTask(new Check($this,$args[0],$pl),1);
    $p=$this->getServer()->getPlayer($args[0]);
    	$p->teleport(new Vector3(41,72,45));
    $h = $p->getHealth();
    $this->config->set("sn",$args[0]);
    $this->config->set("n",$comsend->getName());
    $this->config->set("healing$args[0]",true);
    $this->config->save();
    $this->getServer()->getScheduler()->scheduleRepeatingTask(new Timer($this),20*8);
    $p->sendMessage("§l§aВас положили в больницу!");
    $comsend->sendMessage("§l§aВы положили пациента $args[0]!");
    return true;
    }
    else
    {
    $comsend->sendMessage("§cВы не врач!");
    return true;
    }
    return true;
    }
    else
    {
    $comsend->sendMessage("§l§cГде гражданин?");
    return true;
    }
    return true;
    }
    if ($ap == "setcar")
    {
    if (isset($args[0]))
    {
    if ($args[0] == "on")
    {
    $n = $comsend->getName();
    $c = $this->config->get("carbuyed$n");
    $p = $comsend->getPlayer();
    if ($c == true)
    {
    if (!$this->config->exists("xcar$n") && !$this->config->exists("ycar$n") && !$this->config->exists("zcar$n"))
    {
    $x=$p->getX();
    $y=$p->getY();
    $z=$p->getZ();
    $this->config->set("xcar$n",$x);
    $this->config->set("ycar$n",$y);
    $this->config->set("zcar$n",$z);
    $this->config->save();
    }
    $gx=$this->config->get("xcar$n");
    $gy=$this->config->get("ycar$n");
    $gz=$this->config->get("zcar$n");
    $x=$p->getX();
    $y=$p->getY();
    $z=$p->getZ();
    if ($x == $gx && $y == $gy && $z == $gz)
    {
    $speed = Effect::getEffect(1); //Effect Id for Speed
    $speed->setDuration(20*99999); //the Duration for the effect
    $speed->setAmplifier(6); //Amplifier for effect
    $speed->setVisible(false);
    $comsend->getPlayer()->addEffect($speed);
    $comsend->sendMessage("§l§lВы включили машину");
    return true;
    }
    else
    {
    $comsend->sendMessage("§f§lВы не на месте парковке машины!Заказать такси к машине:/setcar tp§a(Бесплатно) ");
    return true;
    }
    return true;
    }
    else
    {
    $comsend->sendMessage("§lКупите машину!");
    return true;
    }
    return true;
    }
    else if ($args[0] == "off")
    {
    $n = $comsend->getName();
    $c = $this->config->get("carbuyed$n");
    $p = $comsend->getPlayer();
    $x=$p->getX();
    $y=$p->getY();
    $z=$p->getZ();
    if ($c == true)
    {
    $this->config->set("xcar$n",$x);
    $this->config->set("ycar$n",$y);
    $this->config->set("zcar$n",$z);
    $this->config->save();
    $comsend->getPlayer()->removeAllEffects();
    $comsend->sendMessage("§l§fВы выключили машину");
    return true;
    }
    return true;
    }
    else if ($args[0] == "tp")
    {
    $n = $comsend->getName();
    $gx=$this->config->get("xcar$n");
    $gy=$this->config->get("ycar$n");
    $gz=$this->config->get("zcar$n");
    $p = $comsend->getPlayer();
    $p->teleport(new Vector3($gx,$gy,$gz));
    $p->sendMessage("§f§lВы приехали к машине!Теперь стойте на месте и заведите машину,если хотите на ней поехать!");
    return true;
    }
    return true;
    }
    else
    {
    return false;
    }
    return true;
    }
   if ($ap == "buycar")
   {
   if ($mym>=8000)
   {
   $n = $comsend->getName();
   $c=$this->config->get("carbuyed$n");
   if ($c == false)
   {
   $this->config->set("carbuyed$n",true);
   $ecapi->reduceMoney($comsend->getPlayer(),8000);
   $this->config->save();
   $comsend->sendMessage("§l§fВы купили машину!");
   return true;
   }
   else
   {
   $comsend->sendMessage("§l§cВы покупали машину!");
   return true;
   }
   return true;
   }
   return true;
   }
	if ($ap == "newbie")
	{
		$name = $comsend->getName();
		$comsend->sendMessage("§a§lПривет!Рад,что ты в нашем уютном городке!\nТы,наверное §oновенький§r§l§a.Давай пройдемся по стандарту.\nДля того,чтобы §eсказать \nчто-то,что ты делаешь,пиши §c/me <Действие>§a.\nЕсли ты §eхочешь описать \nобстановку вокруг себя,тебе подойдет:\n§c/do <Фраза>§a.\nНапример:§c/do В кармане деньги§a.\n Выведется:\n§bВ кармане деньги.|.$name..\nМы пока строим новые дома,поэтому \n §eты пока поживешь на вокзале.§a\n§k|§r§a§lНадеемся на вашу поддержку!§k|§r");
	return true;
	}
	if ($ap == "showpass")
	{
	if (isset($args[0]))
	{
	$p = $comsend->getPlayer();
	$ppapi = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
	$pg = $ppapi->getUserDataMgr()->getGroup($p)->getName();
	$n = $comsend->getName();
	$name = $args[0];
	$ps = "МЮ";
	$sn = $this->config->get("sernum$n");
	$sename=$this->config->set("sendname$n",$n);
	$gived = $this->config->get("passgived$n");
	if ($gived == true)
	{
	$level = $this->getServer()->getLevelByName("world");
	$level->addSound(new AnvilUseSound($this->getServer()->getPlayer($name)));
	$this->getServer()->getPlayer($name)->sendMessage("§l§c-_-_-_Пасспорт игрока $n:-_-_-_-_\n§eРабота:§c$pg\n§eСерия:§c$ps$sn");
    return true;
    }
    else
    {
    	$level = $this->getServer()->getLevelByName("world");
        	$level->addSound(new GenericSound($p,1007));
    $comsend->sendMessage("§l§cВам выдавали пасспорт?");
    }
    return true;
    }
    else
    {
    $comsend->sendMessage("§l§cПочему же нету кому показать?");
    return true;
    }
    return true;
    }
    if ($ap == "givepass")
    {
    $p = $comsend->getPlayer();
    $xx1 = 109;
    $xx2 = 115;
    $yy1 = 61;
    $yy2 = 72;
    $zz1 = 94;
    $zz2 = 100;
    if ($p->getX() >= $xx1 && $p->getX() <= $xx2 && $p->getY() >= $yy1 && $p->getY() <= $yy2 && $p->getZ() >= $zz1 && $p->getZ() <= $zz2) {
    $name = $args[0];
    $ch = $this->config->get("passgived$name");
    if (!$this->config->exists("passgived$name"))
    {
    $this->config->set("passgived$name",false);
    $this->config->save();
    }
    if ($ch == false)
    {
    if (isset($args[0]))
    {
    if ($p->isOnline())
    {
        $name = $args[0];
        $p = $this->getServer()->getPlayer($name);
    	$level = $this->getServer()->getLevelByName("world");
    	$level->addSound(new GenericSound($p,1018));
    $comsend->sendMessage("§o§eВы выдали паспорт игроку $name!");
    $this->config->set("passgived$name",true);
    $this->config->save();
    return true;
    }
    return true;
    }else if (!$p->isOnline())
    {
    $comsend->sendMessage("§l§cНе найдено такого гражданина!");
    return true;
    }
    else
    {
    $comsend->sendMessage("§l§cКак гражданин-то зовется?");
    return true;
    }
    return true;
    }
    else
    {
    $comsend->sendMessage("§l§cЗачем перевыдавать пасспорт?");
    return true;
    }
    return true;
    } else {
    $comsend->sendMessage("§l§aВы должны находиться в комнате выдачи паспортов!");
    return true;
    }
    return true;
    }
    }
    public function money()
    {
    foreach ($this->getServer()->getOnlinePlayers() as $p)
    {
    EconomyAPI::getInstance()->addMoney($p,rand(100,400));
    $p->sendMessage("§e§lВы получили бонус за игру!");
    }
    }
    public function onEnable()
    {
		if (!is_dir($this->getDataFolder()))
		{
			mkdir($this->getDataFolder());
		}

		$this->saveResource("config.yml");
		$this->config = new Config($this->getDataFolder() ."config.yml",Config::YAML);
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
    $this->getLogger()->info(TextFormat::GREEN."Запущен плагин.");
    
   }
	public function onDisable()
	{
		$this->getLogger()->info(TextFormat::RED."Выключаю плагин.");
	}

}
?>