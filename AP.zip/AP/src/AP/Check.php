<?php
namespace AP;
use pocketmine\scheduler\Task;
class Check extends Task
{
	private $main,$n,$p;
	public function __construct($main,$n,$p)
	{
		$this->main = $main;
		$this->n = $n;
		$this->p=$p;
	}
	public function onRun($tick)
	{
		$this->main->checkheal($n,$p);	
	}
}
?>